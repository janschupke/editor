#! /usr/bin/sh

java -jar Odk.jar